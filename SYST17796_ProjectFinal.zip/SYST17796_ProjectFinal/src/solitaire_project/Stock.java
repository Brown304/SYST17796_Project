package solitaire_project;

/**
 *
 * @author Saad Aziz, Rohit Kumar and Joshua Brown / 2021-04-20
 */
public class Stock extends GroupOfCards {

    public Stock(int size) {
        this.size = size;
    }

}
