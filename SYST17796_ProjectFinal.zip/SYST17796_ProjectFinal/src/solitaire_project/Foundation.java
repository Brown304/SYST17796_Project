package solitaire_project;

/**
 *
 * @author Saad Aziz, Rohit Kumar and Joshua Brown / 2021-04-20
 */

  public class Foundation extends GroupOfCards {

    public Foundation(int size) {
        this.size = size;
    }

}
